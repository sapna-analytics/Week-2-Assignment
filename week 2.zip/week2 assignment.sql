-- Display the sales data

select * from sql_sales_dataset

-- Find the total number of orders

SELECT COUNT(DISTINCT order_id) AS total_orders
FROM sql_sales_dataset

-- Calculate total sales

SELECT SUM(total_price) AS total_sales
FROM sql_sales_dataset

-- Calculate the average order value

SELECT AVG(total_price) AS average_order_value
FROM sql_sales_dataset

-- Find the average order value by region

SELECT
    region,
    AVG(total_price) AS average_order_value
FROM sql_sales_dataset
GROUP BY region
ORDER BY average_order_value DESC

-- Find the top 5 customers by total spending

SELECT TOP 5
    customer_name,
    SUM(total_price) AS total_spending
FROM sql_sales_dataset
GROUP BY customer_name
ORDER BY total_spending DESC

-- Find the number of orders placed by each customer

SELECT
    customer_name,
    COUNT(DISTINCT order_id) AS total_orders
FROM sql_sales_dataset
GROUP BY customer_name
ORDER BY total_orders DESC

-- Find customers whose total spending is above the average customer spending

SELECT
    customer_name,
    SUM(total_price) AS total_spending
FROM sql_sales_dataset
GROUP BY customer_name
HAVING SUM(total_price) > (
    SELECT AVG(customer_total)
    FROM (
        SELECT
            customer_name,
            SUM(total_price) AS customer_total
        FROM SQL_Sales_Dataset
        GROUP BY customer_name
    ) AS customer_spending
)
ORDER BY total_spending DESC

-- Categorize orders by value using CASE

SELECT
    order_id,
    customer_name,
    total_price,
    CASE
        WHEN total_price >= 10000 THEN 'High Value'
        WHEN total_price >= 5000 THEN 'Medium Value'
        ELSE 'Low Value'
    END AS order_category
FROM SQL_Sales_Dataset